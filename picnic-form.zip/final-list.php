<?php require_once('header.php'); 
?>
	<div class="container">
		<div class="row">
			<div class="col-sm-6">	
				<div class="form-group">
					<h4 class="form-title">Your picnic form has been submitted sucessfully!</h4>
					<h6>Listed below are your details and the food items your selected.</h6>
				</div>
				<div class="user-details">
					<div class="form-group final-details-form-group">
						<label>Name: <span><?php echo $_SESSION['firstname']." ".$_SESSION['lastname']; ?></span></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Email Address: <span><?php echo $_SESSION['email']; ?></span></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Contact Number: <span><?php echo $_SESSION['contact']; ?></span></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Gender: <span><?php echo $_SESSION['gender']; ?></span></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Batch Year: <span><?php echo $_SESSION['batch']; ?></span></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Food Preference: <span><?php echo $_SESSION['food']; ?></span></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Breakfast: <ul>
							<?php $breakfasts = $_SESSION['breakfast']; 
							foreach($breakfasts as $breakfast){
								echo "<li>" . $breakfast . "</li>";
							}
							?>
						</ul></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Lunch: <ul>
							<?php $lunches = $_SESSION['lunch']; 
							foreach($lunches as $lunch){
								echo "<li>" . $lunch . "</li>";
							}
							?>
						</ul></label>
					</div>
					<div class="form-group final-details-form-group">
						<label>Beverages: <ul>
							<?php $beverages = $_SESSION['beverages']; 
							foreach($beverages as $beverage){
								echo "<li>" . $beverage . "</li>";
							}
							?>
						</ul></label>
					</div>
				</div>
			</div>

			<div class="col-sm-6">
				<div class="pic-logo">
					<img src="logo.jpg" alt="college-logo.jpg">
				</div>
			</div>
		</div> <!-- .row -->
	</div> <!-- .container -->

<?php require_once('footer.php'); ?>