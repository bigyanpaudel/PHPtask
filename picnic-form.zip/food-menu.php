<?php require_once('header.php'); 
if(isset($_POST['breakfast'])){
	$breakfast= $_POST['breakfast'];
	$_SESSION['breakfast'] = $breakfast;
}

if(isset($_POST['lunch'])){
	$lunch= $_POST['lunch'];
	$_SESSION['lunch'] = $lunch;
}

if(isset($_POST['beverages'])){
	$beverages= $_POST['beverages'];
	$_SESSION['beverages'] = $beverages;
	var_dump($_SESSION['beverages']);
}

?>
	<div class="container">
		<div class="row">
			<div class="col-sm-6">	
				<h2 class="form-title">Food Menu</h4>
				<form class="food-form" action="final-list.php" method="post">
					<div class="form-group">
						<label class="food-item">Breakfast</label>
						<div class="food-menu-wrapper">
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="milktea" name="breakfast[]" value="Tea/Coffee">
							  <label class="custom-control-label" for="milktea">Tea/Coffee</label>
							</div>		
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="breadjam" name="breakfast[]" value="Bread & Jam">
							  <label class="custom-control-label" for="breadjam">Bread & Jam</label>
							</div>			
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="breadneggs" name="breakfast[]" value="Bread & Omelette">
							  <label class="custom-control-label" for="breadneggs">Bread & Omelette</label>
							</div>		
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="aaloochana" name="breakfast[]" value="Aaloo Chana">
							  <label class="custom-control-label" for="aaloochana">Aaloo Chana</label>
							</div>	
						</div>				
					</div>
					<div class="form-group">
						<label class="food-item">Lunch</label>
						<div class="food-menu-wrapper">
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="rice" name="lunch[]" value="Rice/Pulau">
							  <label class="custom-control-label" for="rice">Rice/Pulau</label>
							</div>		
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="chappati" name="lunch[]" value="Chappati">
							  <label class="custom-control-label" for="chappati">Chappati</label>
							</div>			
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="vegetables" name="lunch[]" value="Vegetables">
							  <label class="custom-control-label" for="vegetables">Vegetables</label>
							</div>		
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="chicken" name="lunch[]" value="Chicken">
							  <label class="custom-control-label" for="chicken">Chicken</label>
							</div>			
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="salad" name="lunch[]" value="Salad">
							  <label class="custom-control-label" for="salad">Salad</label>
							</div>
						</div>						
					</div>
					<div class="form-group">
						<label class="food-item">Beverages</label>
						<div class="food-menu-wrapper">
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="coke" name="beverages[]" value="Coke">
							  <label class="custom-control-label" for="coke">Coke</label>
							</div>		
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="fanta" name="beverages[]" value="Fanta">
							  <label class="custom-control-label" for="fanta">Fanta</label>
							</div>			
							<div class="custom-control custom-checkbox">
							  <input type="checkbox" class="custom-control-input" id="sprite" name="beverages[]" value="Sprite">
							  <label class="custom-control-label" for="sprite">Sprite</label>
							</div>	
						</div>			
					</div>
					<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div>
			<div class="col-sm-6">
				<div class="pic-logo">
					<img src="logo.jpg" alt="college-logo.jpg">
				</div>
			</div>
		</div> <!-- .row -->
	</div> <!-- .container -->

<?php require_once('footer.php'); ?>