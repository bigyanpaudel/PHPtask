<?php require_once('header.php'); ?>
	<?php 

	if(isset($_POST['fname'])){
		$firstname = $_POST['fname'];
		$_SESSION['firstname'] = $firstname;
	} 
	if(isset($_POST['lname'])){
			$lastname = $_POST['lname'];
			$_SESSION['lastname'] = $lastname;
		} 
	if(isset($_POST['email'])){
			$email = $_POST['email'];
			$_SESSION['email'] = $email;
		} 
	if(isset($_POST['cnumber'])){
			$cnumber = $_POST['cnumber'];
			$_SESSION['contact'] = $cnumber;
		} 
	if(isset($_POST['gender'])){
			$gender = $_POST['gender'];
			$_SESSION['gender'] = $gender;
		} 
	if(isset($_POST['select-batch'])){
			$batch = $_POST['select-batch'];
			$_SESSION['batch'] = $batch;
		} 
	if(isset($_POST['food-preference'])){
			$food_preference = $_POST['food-preference'];
			$_SESSION['food'] = $food_preference;
		}

	?>
	<div class="container">
		<div class="row">
			<div class="col-sm-6">	
				<h2 class="form-title">Deer Picnic</h4>
				<form class="picnic-form" action="food-menu.php" method="post">
					<div class="form-group">
						<label for="firstname">First Name*</label>
						<input type="text" name="fname" class="form-control" placeholder="First Name*">
					</div>	
					<div class="form-group">
						<label for="lastname">Last Name*</label>
						<input type="text" name="lname" class="form-control" placeholder="Last Name*">
					</div>
					<div class="form-group">
						<label for="email">Email address*</label>
						<input type="email" name="email" class="form-control" placeholder="Email*">
					</div>
					<div class="form-group">
						<label for="contact">Contact Number</label>
						<input type="number" name="cnumber" class="form-control" placeholder="+977-9812345678">
					</div>
					<div class="form-group">
						<div>
							<label>Select Your Gender</label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="gender"value="male">
						  <label class="form-check-label">Male</label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="gender"value="female">
						  <label class="form-check-label">Female</label>
						</div>
					</div>
					<div class="form-group">
						<select class="custom-select" name="select-batch">
							<option selected>Select Your Batch</option>
							<option value="2018">2018</option>
							<option value="2019">2019</option>
							<option value="2020">2020</option>
							<option value="2021">2021</option>
							<option value="Faculty">Faculty</option>
						</select>
					</div>
					<div class="form-group">
						<div>
							<label>Food Preferences</label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="food-preference" value="veg">
						  <label class="form-check-label">Veg</label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="food-preference" value="nonveg">
						  <label class="form-check-label">Nonveg</label>
						</div>
					</div>
					<button type="submit" class="btn btn-primary" name="user-details">Submit</button>
				</form>
			</div>
			<div class="col-sm-6">
				<div class="pic-logo">
					<img src="logo.jpg" alt="college-logo.jpg">
				</div>
			</div>
		</div> <!-- .row -->
	</div> <!-- .container -->

<?php require_once('footer.php'); ?>