
	<script type="text/javascript" src="bootstrap.min.js"></script>
</body>

</html>

<?php session_destroy(); ?>