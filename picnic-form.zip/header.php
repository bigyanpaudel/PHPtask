<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Picnic Form | DWIT</title>
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>